#Download 10 HIV-1 genomes and use them as an input for your application. Adapt your current algorithm for peer-wise allignment of 2 genomes. Note: take into consideration the fact that your current implementation can't align 2 genomes directly. Therefore, you must find a strategy in which the 2 genomes can be aligned step by step on smaller regions. Make the allignment between each genomes.
#1.Show the alignment between the genomes in the console
#2.Make the visual representation of the alignment in which the regions that are similar are shown as '/'

import os

def needleman_wunsch(s1, s2, match=1, mismatch=-1, gap=0):
    n, m = len(s1), len(s2)
    score = [[0]*(m+1) for _ in range(n+1)]
    ptr = [['']*(m+1) for _ in range(n+1)]
    ptr[0][0] = 'E'
    for i in range(1, n+1):
        score[i][0] = score[i-1][0] + gap
        ptr[i][0] = 'U'
    for j in range(1, m+1):
        score[0][j] = score[0][j-1] + gap
        ptr[0][j] = 'L'
    for i in range(1, n+1):
        for j in range(1, m+1):
            diag = score[i-1][j-1] + (match if s1[i-1]==s2[j-1] else mismatch)
            up = score[i-1][j] + gap
            left = score[i][j-1] + gap
            best = diag
            p = 'D'
            if up > best:
                best = up; p = 'U'
            if left > best:
                best = left; p = 'L'
            score[i][j] = best
            ptr[i][j] = p

    i, j = n, m
    a1, a2, mid = [], [], []
    while i>0 or j>0:
        p = ptr[i][j]
        if p == 'D':
            x, y = s1[i-1], s2[j-1]
            a1.append(x); a2.append(y)
            mid.append('/' if x == y else ' ')
            i -= 1; j -= 1
        elif p == 'U':
            a1.append(s1[i-1]); a2.append('-'); mid.append(' ')
            i -= 1
        else:
            a1.append('-'); a2.append(s2[j-1]); mid.append(' ')
            j -= 1
    return ''.join(reversed(a1)), ''.join(reversed(a2)), ''.join(reversed(mid))

def load_genome(path):
    with open(path) as f:
        lines = f.readlines()
    return ''.join([l.strip() for l in lines if not l.startswith('>')])

def align_large_genomes(seq1, seq2, window=800):
    aligned1, aligned2, aligned_mid = [], [], []
    for start in range(0, min(len(seq1), len(seq2)), window):
        sub1 = seq1[start:start+window]
        sub2 = seq2[start:start+window]
        a1, a2, mid = needleman_wunsch(sub1, sub2)
        aligned1.append(a1)
        aligned2.append(a2)
        aligned_mid.append(mid)
    return ''.join(aligned1), ''.join(aligned2), ''.join(aligned_mid)

folder = "/Users/Admin/Desktop/10genomes_2" 
files = [f for f in os.listdir(folder) if f.endswith(".fna")]

genomes = []
for f in sorted(files):
    genomes.append((f, load_genome(os.path.join(folder, f))))

for i in range(len(genomes)):
    for j in range(i+1, len(genomes)):
        name1, g1 = genomes[i]
        name2, g2 = genomes[j]
        print(f"Alignment: {name1} vs {name2}")
        a1, a2, mid = align_large_genomes(g1, g2, window=800)
        print(a1[:300])   
        print(mid[:300])
        print(a2[:300])
        print("...\n")

#3. For each alignment, calculate the similarity score and make a table that shows the similarity score for each alignment.

        matches = mid.count('/')
        length = len(a1)
        similarity_pct = (matches * 100) // length if length else 0
        print(f"Similarity: {similarity_pct}%\n")
        print("...\n")
        