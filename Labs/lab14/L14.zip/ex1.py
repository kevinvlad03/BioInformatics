#Natively, without importing any libraries, Implement a software application that aligns two DNA sequences by using the Needleman–Wunsch algorithm:
#S1="ACCGTGAAGCCAATAC"
#S2="AGCGTGCAGCCAATAC"

def needleman_wunsch(seq1, seq2, match=1, mismatch=1, gap=0):
    n, m = len(seq1), len(seq2)
    score = [[0] * (m + 1) for _ in range(n + 1)]
    ptr = [[''] * (m + 1) for _ in range(n + 1)]
    ptr[0][0] = 'E'
    for i in range(1, n + 1):
        score[i][0] = score[i - 1][0] + gap
        ptr[i][0] = 'U'

    for j in range(1, m + 1):
        score[0][j] = score[0][j - 1] + gap
        ptr[0][j] = 'L'

    for i in range(1, n + 1):
        c1 = seq1[i - 1]
        for j in range(1, m + 1):
            c2 = seq2[j - 1]
            diag = score[i - 1][j - 1] + (match if c1 == c2 else mismatch)
            up   = score[i - 1][j] + gap
            left = score[i][j - 1] + gap

            best = diag
            p = 'D'
            if up > best:
                best = up
                p = 'U'
            if left > best:
                best = left
                p = 'L'

            score[i][j] = best
            ptr[i][j] = p

    i, j = n, m
    a1, a2, mid = [], [], []
    while i > 0 or j > 0:
        p = ptr[i][j]
        if p == 'D':
            x, y = seq1[i - 1], seq2[j - 1]
            a1.append(x); a2.append(y)
            mid.append('|' if x == y else '.')
            i -= 1; j -= 1
        elif p == 'U':
            a1.append(seq1[i - 1]); a2.append('-'); mid.append(' ')
            i -= 1
        else:  # 'L'
            a1.append('-'); a2.append(seq2[j - 1]); mid.append(' ')
            j -= 1

    a1 = ''.join(reversed(a1))
    a2 = ''.join(reversed(a2))
    mid = ''.join(reversed(mid))

    matches = mid.count('|')
    length = len(a1)
    similarity_pct = (matches * 100) // length if length else 0

    return {
        "score": score[n][m],
        "aligned_s1": a1,
        "aligned_s2": a2,
        "match_line": mid,
        "matches": matches,
        "length": length,
        "similarity_pct": similarity_pct,
        "score_matrix": score,   
        "traceback": ptr
    }

S1 = "ACCGTGAAGCCAATAC"
S2 = "AGCGTGCAGCCAATAC"

res = needleman_wunsch(S1, S2, match=1, mismatch=-1, gap=0)

print("Score:", res["score"])
print(res["aligned_s1"])
print(res["match_line"])
print(res["aligned_s2"])
print()
print("Matches:", res["matches"])
print("Length :", res["length"])
print("Similarity:", str(res["similarity_pct"]) + "%")
    